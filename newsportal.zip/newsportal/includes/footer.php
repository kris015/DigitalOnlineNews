    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; KIZO SPORT - All rights reserved <?php echo date('Y');?></p>
      </div>
      <!-- /.container -->
    </footer>