<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Popup Primer</title>
    <style>
        /* Stilizacija popup-a */
        #popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        #popup-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
        }

        /* Stilizacija dugmeta */
        #loginButton {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <!-- Popup sadržaj -->
    <div id="popup">
        <div id="popup-content">
            <p>Ova opcija je trenutno onemogucena!</p>
            <button id="loginButton" onclick="redirectToLogin()"> Back to Login</button>
        </div>
    </div>

    <script>
        // JavaScript kod za automatsko otvaranje popup-a prilikom učitavanja stranice
        window.onload = function() {
            document.getElementById('popup').style.display = 'block';
        };

        // JavaScript kod za preusmeravanje na login.php
        function redirectToLogin() {
            window.location.href = '../';
        }
    </script>

</body>
</html>

